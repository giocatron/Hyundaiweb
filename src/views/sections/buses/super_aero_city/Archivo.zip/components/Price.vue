<template>
    <div id="price_section">
      <iframe id="bx_form_iframe_177" name="bx_form_iframe_177" src="https://automotor.bitrix24.es/pub/form.php?view=frame&amp;form_id=177&amp;widget_user_lang=la&amp;sec=e4pbyq&amp;r=1606938181845#%7B%22domain%22%3A%22file%3A%2F%2F%22%2C%22from%22%3A%22file%3A%2F%2F%2FUsers%2Fimac2%2FDesktop%2Fframe.html%22%2C%22options%22%3A%7B%7D%7D" scrolling="no" frameborder="0" marginheight="0" marginwidth="0" style="width: 100%; height: 766px; border: 0px; overflow: hidden; padding: 0; margin: 0;"></iframe>
    </div>
</template>
