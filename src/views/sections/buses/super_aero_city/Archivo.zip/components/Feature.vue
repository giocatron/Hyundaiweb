<template>
    <div>
        <div class="container">
            <div class="title">Super Aereo City</div>
            <div class="longtext text-left px-5">
                Hyundai desarrolló buses de media distancia para satisfacer los requerimientos de transporte de empresas de todo tipo. <br><br> El Super Aero City para 38 pasajeros está pensado para compañías de transporte público en grandes ciudades.
            </div>
            <div class="main-image d-flex justify-content-center">
                <div>
                    <img :src="`../static/img/section_transport/buses/super_aero_city/main.png`" alt="Hyundai Accent de costado y atras" class="img-fluid">
                </div>
            </div>
            <price></price>
        </div>
    
        <!-- end cream zone -->
        <div class="galery-zone">
            <div class="title">Galería</div>
            <div class="download-link container my-2 text-right">
                <a href="../static/catalogs/super_aero_city.pdf" target="_blank"> Descargar Ficha técnica</a>
            </div>
        </div>
        <gallery></gallery>
    </div>
</template>

<script>
import Price from '@/views/sections/buses/super_aero_city/components/Price.vue'
import Gallery from '@/views/sections/buses/super_aero_city/components/Gallery.vue'
export default {
    components: {
        Gallery,
         Price
    }
}
</script>

